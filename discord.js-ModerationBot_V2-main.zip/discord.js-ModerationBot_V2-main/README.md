# discord.js-ModerationBot_V2
ModerationBot_V2 is an advanced version of ModerationB_V1 with a lot of Awesome features added commands!! This include a dynamic help commands and some fixed bugs.. This is the 2nd Version of ModerationBot and further updates will be made soon.. So make sure to follow me on **[GitHub](https://github.com/drstrangegithub)** for latest updates!!

# Setup
Import the project into repl.it and then fill out your bot token in config.js file.. Then type npm install in the console and let repl.it install all the packages..
Next put Your Bot token in the client secret option.. And then just run the bot!! Yes it's that easy to make your bot safe and Setting it up :)

# Video setup guide
Check out this **[Video](https://www.youtube.com/watch?v=S0_E9YdTGis&t=69s)** For explained setup guide..
And if you want more easy bot tutorials Subscribe to the **[CHANNEL](https://www.youtube.com/channel/UCmTSEzt4h1S4MiCM1grWu9g)** That will support me a lot!!

**Thanks for Choosing MODERATION_V2**
